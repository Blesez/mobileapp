import 'package:flutter/material.dart';
import 'package:flutter/foundation.dart';
import 'Screens/Login_screen.dart';
import 'Screens/Home_screen.dart';
import 'package:provider/provider.dart';
import 'package:web_socket_channel/io.dart';
import 'Messages.dart';
import 'package:web_socket_channel/web_socket_channel.dart';
import 'dart:io';


void main() => runApp(MyApp());

const url = 'wss://72daer0qkc.execute-api.us-east-1.amazonaws.com/beta?token:App';

class MyApp extends StatelessWidget {
  const MyApp({super.key});
  @override
  Widget build(BuildContext context) {
   
    return ChangeNotifierProvider(
      create: (_) => MyData(),
    child: MaterialApp(
      home:  FutureBuilder<WebSocketChannel>(
          future: connectToWS(),
          builder: (context, snapshot) {
            if (snapshot.connectionState == ConnectionState.done &&
                snapshot.hasData) {
                    Messages(channel: snapshot.data!);
              return HomeScreen(channel: snapshot.data!);
              
            } else if (snapshot.hasError) {
              return Scaffold(
                body: Center(
                  child: Text('Error: ${snapshot.error}'),
                ),
              );
            } else {
              return Scaffold(
                body: Center(
                  child: CircularProgressIndicator(),
                ),
              );
            }
          },
        ),
      ),
    );
  }

 Future<WebSocketChannel> connectToWS() async {
  try {
    final channel = IOWebSocketChannel(await WebSocket.connect('$url:42686'));
    // websocket connection successful, handle further actions here
    return channel;
  } on SocketException catch (e) {
    if (e.osError?.errorCode == 111) {
       
      throw Exception('Connection refused');
     
    } else {
      debugPrint("unexpected socket exception: $e");
      
      throw Exception('unexpected socket exception');
    }
  } catch (e) {
    print('unexpected exception: $e');
    throw Exception('Unexpected exception');
  }
}


}



class MyData with ChangeNotifier{
  int NumOfTank = 0;
  List <double> TankValues = [];
  String PumpState = '';

  void updateNumOfTank(int _NumOfTank){
    NumOfTank = _NumOfTank;
    notifyListeners();
  }

  void updateTankValues(List <double>_TankValue){
    TankValues = _TankValue;
    notifyListeners();
  }
    void updatePumpState(String _pumpState){
    PumpState = _pumpState;
    notifyListeners();
  }
}