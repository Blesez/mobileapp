
import 'package:provider/provider.dart';
import 'package:web_socket_channel/io.dart';
import 'package:web_socket_channel/web_socket_channel.dart';
import 'package:flutter/material.dart';
import 'package:water_monitoring_app/array.dart';
import 'package:water_monitoring_app/main.dart';
import 'package:water_monitoring_app/progressIndicator.dart';
import 'package:water_monitoring_app/Screens/TankSize_screen.dart';
import 'dart:convert';
import '../TankArrangement.dart';


 //= int.parse(NumInput.text);

class HomeScreen extends StatefulWidget {
  final WebSocketChannel channel;
  const HomeScreen({required this.channel,super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}
class _HomeScreenState extends State<HomeScreen> {
TextEditingController _NumInput = TextEditingController();

 int? _NumOfTank;

 @override
 void initState(){
  super.initState();
  _NumInput.addListener(() {
    setState((){
      try{
        _NumOfTank = int.parse(_NumInput.text);
      } on FormatException {
        _NumOfTank = null;
      }
    });
  });
 }

  @override
  Widget build(BuildContext context) {

    var scaffold = Scaffold(
    appBar: AppBar(
      title: Text('Welcome'.toUpperCase()),
      centerTitle: true,
      ),
        drawer: Drawer(
          
          child: ListView(
            children: [
              DrawerHeader(
                padding: EdgeInsets.all(0),
                child: Container(
                  child: Text("Settings".toUpperCase()),
                  color: Colors.blue.shade300,
                  ),
                  ),
                    ExpansionTile(
                      title: Text('Tanks Available'), 
                      children: [
                          Padding(
                            padding: const EdgeInsets.all(15),
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                TextFormField(
                                 controller: _NumInput,
                                 keyboardType: TextInputType.number,
                                 decoration: InputDecoration( 
                                  border: OutlineInputBorder(),
                                  hintText: context.watch<MyData>().NumOfTank.toString() ) ,
                                  
                                ),
                              SizedBox(width: 10,),
                            
                            ElevatedButton(onPressed: (){
                                context.read<MyData>().updateNumOfTank(_NumOfTank!);
                                 updateNumOfTank();
                                
                                       
                              Navigator.pop(context);
                                
                            }, 
                            child: Text("OK"))
                                                  
                              ]                 
                            ),
                          ),
                        ]
                    ),

            ],
          ),
        ),
  
    body: Container(
      decoration: const BoxDecoration(
        image: DecorationImage(
          image: AssetImage("images/waterbg.jpg"),
          fit: BoxFit.cover,
          )
      ),
      child:  Center(
                 child: Column(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                   children: [
                     Container(
                      alignment:Alignment.topCenter ,
                      width: 500,
                       height: 900,
                           
                     child: Stack(
                         alignment: Alignment.center,
                            children: [
                               Consumer<MyData>(
                              builder:
                              (context, value, child) {
                                return TanksArrangement(numTank: value.NumOfTank);
                              },
                               ), 
                            ],
                            ),
                      ),
                      SizedBox(height: 40,),
                     MyButton(channel: widget.channel),
                  
                              ],
                 ),
               ),
    
        
          
      ), 
      );
    return scaffold;
  }
  
 
 updateNumOfTank(){
                                  var myMapNumOfTank = {
                    'sender' : 'App',
                    'NumOfTank' : _NumInput,
                
  };
  widget.channel.sink.add(myMapNumOfTank);
      
 }
 }

class MyButton extends StatefulWidget {
  final WebSocketChannel channel;
  const MyButton({
    required this.channel,
    Key? key}) : super(key: key);

  @override
  State<MyButton> createState() => _MyButtonState();
}

class _MyButtonState extends State<MyButton> {
 
bool isButtonClicked = false;
Color buttoncolor = Colors.grey;
Text icontext = Text("Turn pump on");

bool isButtonClicked1 = false;
Color buttoncolor1 = Colors.green;
Text icontext1 = Text("Turn pump off");

void togglebuttoncolor(){
  setState(() {
   isButtonClicked = !isButtonClicked;
   buttoncolor = isButtonClicked? Colors.green : Colors.grey;
   icontext = isButtonClicked? Text("Pumping") : Text("Turn pump on");
});
}

void togglebuttoncolor1(){
setState(() {
  isButtonClicked1 = !isButtonClicked1;
  buttoncolor1 = isButtonClicked1? Colors.grey : Colors.green;
  icontext1 = isButtonClicked1? Text("Pump off") : Text("Pumping");
});
}

 @override
  Widget build(BuildContext context) {
 
    switch (context.watch<MyData>().PumpState){

  case 'off' : 
    return Container(
      child: ElevatedButton(
    onPressed: (){
      togglebuttoncolor();   
      context.read<MyData>().updatePumpState('on');
       var messagetoserver = {
          'sender': 'App',
          'PumpState': 'on',
       };
      widget.channel.sink.add(messagetoserver);
      },
      child: icontext,
      style: ButtonStyle(
        backgroundColor: MaterialStatePropertyAll(buttoncolor),
        elevation: MaterialStatePropertyAll(30),
        shape: MaterialStatePropertyAll(StadiumBorder(side: BorderSide(width: 3.0,)))
      ) , 
      ),
    );
  break;

  case 'on' : 
 return Container(
   child: ElevatedButton(
    onPressed: (){
      togglebuttoncolor1();   
      context.read<MyData>().updatePumpState('off');
       var messagetoserver = {
          'sender': 'App',
          'PumpState': 'off',
       };
      widget.channel.sink.add(messagetoserver);
      },
      child: icontext1,
      style: ButtonStyle(
        backgroundColor: MaterialStatePropertyAll(buttoncolor1),
        elevation: MaterialStatePropertyAll(30),
        shape: MaterialStatePropertyAll(StadiumBorder(side: BorderSide(width: 3.0,)))
      ) , 
      ),
 ); 
  break;

  default: 
    return Container(
      child: ElevatedButton(
    onPressed: (){},
      child: Text('pump state unknown'),
      style: ButtonStyle(
        backgroundColor: MaterialStatePropertyAll(buttoncolor1),
        elevation: MaterialStatePropertyAll(30),
        shape: MaterialStatePropertyAll(StadiumBorder(side: BorderSide(width: 3.0,)))
      ) , 
      ),
    );
  
  break;
  }
  }
}
 



   