import 'package:provider/provider.dart';
import 'package:web_socket_channel/io.dart';
import 'package:web_socket_channel/web_socket_channel.dart';
import 'dart:async';
import 'package:flutter/material.dart';
import 'package:water_monitoring_app/array.dart';
import 'package:water_monitoring_app/main.dart';
import 'package:water_monitoring_app/progressIndicator.dart';
import 'package:water_monitoring_app/Screens/TankSize_screen.dart';
import 'dart:convert';



class Messages extends StatefulWidget {
  final WebSocketChannel channel;
  Messages({required this.channel, super.key, });

  @override
  State<Messages> createState() => _MessagesState();
}

class _MessagesState extends State<Messages> {
   List <double>_TankValues = [];
   String _pumpState = '';

   @override
   void initState(){
    super.initState();
    widget.channel.stream.listen(
      (data) {
        try { 
      final message = jsonDecode(data);
      final List<double> TValues = List <double>.from(message['val']);
      final pumpState = message['pumpState'];

      setState(() {
        _TankValues = TValues;
         _pumpState = pumpState;
      });
      } catch (error){
        debugPrint('ws error $error');
       showDialog(
          context: context,
          builder: (_) => AlertDialog(
            title: Text('Error'),
            content: Text('Failed to connect to the server'),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(context),
                child: Text('OK'),
              ),
            ],
          ),
        );
      }
    },
     onDone: (){
      debugPrint('ws channel closed');
    },
    );
   }

  @override
  Widget build(BuildContext context) {
    return StreamBuilder(
       stream: widget.channel.stream,
        builder: (BuildContext context,AsyncSnapshot snapshot) {
            if(snapshot.hasData){
              final message = jsonDecode(snapshot.data);
                  
                  context.read<MyData>().updateTankValues(_TankValues);
                  context.read<MyData>().updatePumpState(_pumpState);
              
              } 
              throw Exception("cant create widget");
                     },
                );
  }
                @override
                void dispose(){
                  widget.channel.sink.close();
                  super.dispose();
                }
  }

 