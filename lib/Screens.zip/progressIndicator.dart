
import 'package:provider/provider.dart';
import 'package:water_monitoring_app/main.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:flutter/src/widgets/container.dart';
import 'package:liquid_progress_indicator/liquid_progress_indicator.dart';
import 'package:flutter/material.dart';

class LiquidProgress extends StatelessWidget {
  
  Color? backgroundColor;
  double value;
  Axis direction;

  LiquidProgress({
    required this.value,
    required this.direction,
    this.backgroundColor,
 });
  @override
  Widget build(BuildContext context) {
 
    return Container(
      child: Padding(
            padding: const EdgeInsets.all(8.0),
            child: LiquidCustomProgressIndicator(
        value: value,
        backgroundColor: backgroundColor,
        valueColor:AlwaysStoppedAnimation(Colors.lightBlue.shade300),
        direction:direction,
        center: Text(value.toString()), 
        shapePath: _buildTankPath(), ),
          ),
    );
      
  }


}

 Path _buildTankPath(){
    Path path = new Path(); 
    
    path.lineTo(0, 5);
    path.lineTo(20, 5);
    path.lineTo(20, 3);
    path.quadraticBezierTo(40,0,60, 3);
    path.lineTo(60, 5);
    path.lineTo(80,5);
    path.lineTo(80, 117);
    path.lineTo(0,117);
    path.close();
     return path;
   }